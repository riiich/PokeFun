LMS Poke'mon Master TTFs for PC
by London Stokes

These fonts are Freeware, in that you can use them for free of charge
(non commercial purposes only) without getting permission.

If you distribute any of these fonts in any way, this zipfile must be 
kept intact, without alterations.  These fonts, with this read-me file 
my be available for downloading from a website.  Please let me know if
you are including my fonts on a download page.

There are three fonts in this font family.  Poke'mon Master Solid,
Poke'mon Master Outline and Poke'mon Master Dingbats.  In all of these
fonts the same Poke'mon appear on each letter.  Where I was able I used
original pokemon as the lowercase letters and one of their evolutions
on the uppercase letter.  Also where able one of these poke'mons name
begins with the letter it is attached to.  The Poke'mon in this font
are as follows:

0=Cuebone		1=Clafairy		2=Dratini
3=Electrode		4=Geodude		5=Krabby
6=Magikarp		7=Mankey		8=Pidgey
9=Staryu		a=Abra			A=Alacazam
b=Caterpie		B=Butterfree		c=Charmander
C=Charizard		d=Diglet		D=Dugtrio
e=Ekans			E=Arbok			f=Spearow
F=Fearow		g=Gastly		G=Gengar
h=Horsea		H=Seadra		i=Bulbasaur
I=Ivysaur		j=Jigglypuff		J=Wigglytuff
k=Koffing		K=Weezing		L=Lickitung
l=Laprus		m=Mew			M=MewTwo
n=Nidoran (Female)	N=Nidoqueen		o=Oddish
O=Vileplume		p=Pikachu		P=Raichu
q=Meowth		Q=Persian		r=Rattata
R=Raticate		s=Squirtle		S=Blastoise
t=Tentacool		T=Tentacruel		u=Seel
U=Dewgong		v=Vulpix		V=Ninetails
w=Weedle		W=Beedrill		x=Psyduck
X=Golduck		y=Eevee			Y=Vaporeon
z=Zubat			Z=Golbat

I tried to pick the most popular Poke'mon, but with 150 in the original
game, I'm sure I missed someones favorite.

Poke'mon the name and the characters used are copyrighted by Nintendo.
No copyright is claimed or applied in this font.  This font cannot be
used for ANY commercial reason.  Images in these letters were based on
the Poke'mon images found at www.pokemon.com in the "Poke'dex" section.

Please note that the spacing on these fonts are a little off.  Should I
be able to figure out how to fix this I will update with a Ver.2
version of this font.

If you like this font, and feel inclined, please email me at:
RioArizona@hotmail.com and let me know.  It's always a wonderful
feeling to know that your fonts are being downloaded and used!  This
and all my other fonts can be downloaded from the "London's Letters"
web site: http://www.geocities.com/rioarizona/Font.htm


<<<<<<<< CONDITIONS OF USE >>>>>>>>>

1. This font can be used for personal use only. Businesses or companies
   must gain permission for use. 

2. It can not be included in any compilation CD's, disks or product, 
   either commercial or shareware.
   
3. The zipfile containing the font and this text file must be kept
   intact, without alterations, additions or deletions.

4. This font can be transferred, stored or made available to other
   computers or on the internet/bulletin board as long as no fee or
   charge is requested.

5. No warranty is offered, or understood to have been offered by the
   supplier of this font, and the risk of any losses or damage (personal,
   financial or otherwise) from the use of this font remain with the user.

6. The supplier can not be responsible for any problems that may arise
   by misuse of the font. 
